#include <stdio.h>
int main()
{
    int a[5]={1,2,3,4,0};
int b[5]={6,7,8,9,10};
int k=5;
if(k>5)
{
    k=k-5;
    int low=0;
    int high=4;
    int mid=0;
    while(low<=high)
    {
        mid=(low+high)/2;
        if(mid==k-1)
        {
            printf("%d",b[mid]);
            break;
        }
        else if(mid<k-1)
        {
            low=mid+1;
        }
        else
        {
            high=mid-1;
        }
    }
}
else if(k<=5)
{
    int low=0;
    int high=4;
    int mid=0;
    while(low<=high)
    {
        mid=(low+high)/2;
        if(mid==k-1)
        {
            printf("%d",a[mid]);
            break;
        }
        else if(mid<k-1)
        {
            low=mid+1;
        }
        else
        {
            high=mid-1;
        }
    }
}
    return 0;
}